#ifndef SFT_MAIN_H
#define SFT_MAIN_H

#include <iostream>
#include <cstdlib>
#include <cstring>
#include <pthread.h>
#include <alsa/asoundlib.h>
//#include <condition_variable>
//#include <mutex>
#include <thread>
#include <future>
//#include <queue>
#include <chrono>
#include <csignal>
#include <sys/types.h>
#include <ifaddrs.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <linux/if_link.h>
#include <uvgrtp/lib.hh>
#include <netdb.h>
#include <opus/opus.h>
#include "ext/RtAudio/RtAudio.h"
#include "ext/inipp/inipp.h"
#include "ext/loguru/loguru.hpp" 
#include "components/gpioHandler/gpioHandler.hpp"
#include "components/mqttClient/mqttClient.hpp"
#include "includes/Config.hpp"
#include "includes/CircularBuffer.hpp"
#include "components/displayHandler/displayHandler.hpp"
#include "includes/jsonClasses/HandshakeMessage.hpp"

//#define STUDENT_DEVICE 0
//#define TEACHER_DEVICE 1

//Audio
//#define _GNU_SOURCE
#define AUDIO_DEVICE_IN_STUDENT 3          // device 1 = loopback, device 2 on Raspberry Pi is built in [bcm2835 Headphones]
#define AUDIO_DEVICE_IN_TEACHER 2          // device 1 on Raspberry Pi is built in [bcm2835 Headphones]
#define AUDIO_DEVICE_OUT_STUDENT 2         // virtual audio device
#define FRAME_SIZE 960             // frames (20 ms @ 48 kHz)
#define SAMPLE_RATE 48000          //48 kHz
//#define OUTPUT_CHANNELS 1        //output channels (), must match input channels
//#define INPUT_CHANNELS 1         //input channels
#define CHANNELS 1                 //input/output channels must match
#define APPLICATION OPUS_APPLICATION_AUDIO   //VOIP application
//#define BITRATE 96000
#define BITRATE OPUS_BITRATE_MAX    //OPUS max. bitrate
#define COMPLEXITY 10               //max. complexity (10)
#define MAX_FRAME_SIZE 6*FRAME_SIZE
#define MAX_PACKET_SIZE (3*1276)
#define FORMAT RTAUDIO_SINT16
//#define PAYLOAD_MAXLEN 960  
#define BUFFER_MAX_SIZE 20   //samples for 400 ms playback
#define BUFFER_MIN_SIZE 5    //samples for 100 ms playback
#define CIRCULAR_BUFFER_SIZE 200

typedef signed short BYTE_TYPE;
struct AudioFrame {
    opus_int16 frameData[FRAME_SIZE*CHANNELS*2];
    unsigned int size;
};

//declare functions
int streamInOut( void *outputBuffer, void *inputBuffer, unsigned int nBufferFrames, double streamTime, RtAudioStreamStatus status, void *data );
void receiveAudio(void *arg, uvgrtp::frame::rtp_frame *frame);
int audioTransfer();
int audioPlayback();
char* allocate_buffer();
int readModeFromPins();
int readQualityFromPins();
int readFreqSelFromPins();
std::string getLocalIP();
int readStartupConfig();
int readModeConfig(std::string mode);
int initDisplay();
int setupMessages();
void startupDisplayThread(std::future<void> futureObj);
void connectionDisplayThread(std::future<void> futureObj);
void runtimeDisplayThread(std::future<void> futureObj);
void runtimeGPIOThread(std::future<void> futureObj);
void signalHandler(int signum);
int handshakeConnectionTeacher();
int handshakeConnectionStudent();
int handshakeConnection();
int sendSetupMessageTeacher();
int sendSetupMessageStudent();
int sendSetupMessage();
void startHeartbeats();

#endif  //SFT_MAIN_H