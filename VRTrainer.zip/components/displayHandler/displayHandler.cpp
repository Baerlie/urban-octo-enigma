#include "displayHandler.hpp"

using namespace std;

extern MessageModels::QualityMessage qualMsg;
extern MessageModels::SettingsMessage settMsg;
extern std::string mode;
extern bool disconnected;
std::mutex mutDisplay;

DisplayHandler::DisplayHandler()
{}

DisplayHandler::~DisplayHandler()
{}

void DisplayHandler::displayStartup() {    
    char buffer[20];
    std::lock_guard<std::mutex>guard(mutDisplay);
    lcdLoc(LINE1);
    typeln("Starting up.  ");
    lcdLoc(LINE3);
    sprintf(buffer, "Version: %f", APP_VERSION);
    typeln(buffer);
    gpioDelay(1000000);

    lcdLoc(LINE1);
    typeln("Starting up.. ");
    lcdLoc(LINE3);
    sprintf(buffer, "Version: %f", APP_VERSION);
    typeln(buffer);
    gpioDelay(1000000);

    lcdLoc(LINE1);
    typeln("Starting up...");
    lcdLoc(LINE3);
    sprintf(buffer, "Version: %f", APP_VERSION);
    typeln(buffer);
    gpioDelay(1000000);
}

void DisplayHandler::displayConnecting() {    
    std::lock_guard<std::mutex>guard(mutDisplay);
    lcdLoc(LINE1);
    typeln("Connecting.  ");
    gpioDelay(1000000);
    lcdLoc(LINE1);
    typeln("Connecting.. ");
    gpioDelay(1000000);
    lcdLoc(LINE1);
    typeln("Connecting...");
    gpioDelay(1000000); //delay 1s
}

void DisplayHandler::updateDisplayTeacher() {
    std::lock_guard<std::mutex>guard(mutDisplay);
    char buffer1[20], buffer2[20];    //20x4
    char fl1 = ' ', fl2 = ' ', fr1 = ' ', fr2 = ' ';

    //check frequence selection
    if(settMsg.FrequencyActive() == 1){
        fl1 = '>';
        fl2 = '<';
    }
    else {
        fr1 = '>';
        fr2 = '<';
    }

    lcdLoc(LINE1);
    typeln("                    ");
    lcdLoc(LINE2);
    //sprintf(buffer1, "%c%3.3f%c  %c%3.3f%c", fl1, settMsg.FrequencyOne(), fl2, fr1, settMsg.FrequencyTwo(), fr2);

    //aero or naut?
    if(settMsg.Mode() == AERO) {
        sprintf(buffer1, "%c%3.3f%c  %c%3.3f%c", fl1, settMsg.FrequencyOne(), fl2, fr1, settMsg.FrequencyTwo(), fr2);
    }
    else if(settMsg.Mode() == NAUT) {
        //sprintf(buffer1, "%c%3.3f%c  %c%3.3f%c", fl1, settMsg.FrequencyOne(), fl2, fr1, settMsg.FrequencyTwo(), fr2);
        sprintf(buffer1, "    %c%d%c    %c%d%c    ", fl1, static_cast<int>(settMsg.FrequencyOne()), fl2, fr1, static_cast<int>(settMsg.FrequencyTwo()), fr2);
    }
    else {
        sprintf(buffer1, "                   ");
    }

    typeln(buffer1);
    lcdLoc(LINE3);
    typeln("                    ");
    lcdLoc(LINE4);
    sprintf(buffer2, "Q%d REMOTE:%s      %s", qualMsg.QualityRating(), pttToText(settMsg.PushToTalk()).c_str(), pttToText(qualMsg.PushToTalk()).c_str());
    typeln(buffer2);
    //gpioDelay(50000);  //refresh every 0.05s
}


void DisplayHandler::updateDisplayStudent() {
    std::lock_guard<std::mutex>guard(mutDisplay);
    char buffer1[20], buffer2[20];    //20x4
    char fl1 = ' ', fl2 = ' ', fr1 = ' ', fr2 = ' ';

    //check frequence selection
    if(settMsg.FrequencyActive() == 1){
        fl1 = '>';
        fl2 = '<';
    }
    else {
        fr1 = '>';
        fr2 = '<';
    }

    lcdLoc(LINE1);
    typeln("                    ");
    lcdLoc(LINE2);
    //sprintf(buffer1, "%c%3.3f%c  %c%3.3f%c", fl1, settMsg.FrequencyOne(), fl2, fr1, settMsg.FrequencyTwo(), fr2);

    //aero or naut?
    if(settMsg.Mode() == AERO) {
        sprintf(buffer1, "%c%3.3f%c  %c%3.3f%c", fl1, settMsg.FrequencyOne(), fl2, fr1, settMsg.FrequencyTwo(), fr2);
    }
    else if(settMsg.Mode() == NAUT) {
        //sprintf(buffer1, "%c%3.3f%c  %c%3.3f%c", fl1, settMsg.FrequencyOne(), fl2, fr1, settMsg.FrequencyTwo(), fr2);
        sprintf(buffer1, "    %c%d%c    %c%d%c    ", fl1, static_cast<int>(settMsg.FrequencyOne()), fl2, fr1, static_cast<int>(settMsg.FrequencyTwo()), fr2);
    }
    else {
        sprintf(buffer1, "                   ");
    }

    typeln(buffer1);
    lcdLoc(LINE3);
    typeln("                    ");
    lcdLoc(LINE4);
    sprintf(buffer2, "                 %s ", pttToText(settMsg.PushToTalk()).c_str());
    typeln(buffer2);
    //gpioDelay(50000);  //refresh every 0.05s
}

void DisplayHandler::updateDisplay() {
    if(disconnected)
        displayDisconnected();
    else if(!disconnected && mode == "Teacher")
        updateDisplayTeacher();
    else
        updateDisplayStudent();
}

void DisplayHandler::displayDisconnected() {
    std::lock_guard<std::mutex>guard(mutDisplay);
    //char buffer1[20];    //20x4
    clearDisplay();

    lcdLoc(LINE2);
    typeln(" Disconnected!");
    lcdLoc(LINE3);
    typeln("    Please reboot!");
}

void DisplayHandler::removeDisconnected() {
    std::lock_guard<std::mutex>guard(mutDisplay);
    //char buffer1[20];    //20x4
    //TODO
}

void DisplayHandler::clearDisplay() {
    ClrLcd();
}

string DisplayHandler::pttToText(int ptt) {
    if(ptt == 1)
        return "RX";
    else if(ptt == 0)
        return "TX";
    else
        return "EE";
}