#ifndef SFT_DISPLAY_HANDLER_H
#define SFT_DISPLAY_HANDLER_H

#include <iostream>
#include <pigpio.h> // -lpigpio -lrt
#include <cstring>
#include <csignal>
#include <unistd.h>
#include <mutex>
#include "../../includes/Config.hpp"
#include "../../ext/lcd/i2clcd.h"
#include "../../includes/jsonClasses/QualityMessage.hpp"
#include "../../includes/jsonClasses/SettingsMessage.hpp"

class DisplayHandler {
    public:
        DisplayHandler();		
        virtual ~DisplayHandler();		        
        static void displayStartup();
        static void displayConnecting();
        static void displayDisconnected();
        static void removeDisconnected();
        static void clearDisplay();
        static void updateDisplay();
    private:
        static std::string pttToText(int ptt);
        static void updateDisplayTeacher();
        static void updateDisplayStudent();
};

#endif //SFT_DISPLAY_HANDLER_H