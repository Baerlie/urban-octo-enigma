#ifndef SFT_MQQTCLIENT_H
#define SFT_MQQTCLIENT_H

#include <iostream>
#include <cstdlib>
#include <string>
#include <cstring>
#include <cctype>
#include <thread>
#include <chrono>
#include <fstream>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "mqtt/async_client.h"
#include "mqtt/topic.h"
#include "../../includes/jsonClasses/QualityMessage.hpp"
#include "../../includes/jsonClasses/SettingsMessage.hpp"
#include "../../ext/inipp/inipp.h"
#include "../../ext/loguru/loguru.hpp" 
#include "../../includes/Config.hpp"
#include "../displayHandler/displayHandler.hpp"

//external variables
extern std::queue<MessageModels::SettingsMessage> msgQueueSettings;
extern std::queue<MessageModels::QualityMessage> msgQueueQuality;
extern std::queue<std::string> msgQueueHeartbeats;
extern std::condition_variable condMQ, condHB;
extern std::mutex mutMQ;
extern std::mutex mutHB;
extern std::string mode;
extern SFT::Config conf;
extern MessageModels::QualityMessage qualMsg;
extern MessageModels::SettingsMessage settMsg;
extern bool heartbeatReady;

void mqtt_startSubscriber();
void mqtt_startPublisher();
void sendPuredataMessage(int rating);

//const int	QOS = 1;
const int	N_RETRY_ATTEMPTS = 5;
const int   MSG_SIZE = 20;

#endif  //SFT_MQQTCLIENT_H
