#include "mqttClient.hpp"

void mqtt_startPublisher() {
	std::string SERVER_ADDRESS = conf.mqtt_broker;
	std::string CLIENT_ID = conf.mqtt_clientid;
	std::string PUBLISH_TOPIC = conf.mqtt_publish_topic;
	std::string HEARTBEAT_TOPIC = "HB";
	const int QOS = conf.mqtt_qos;
	const bool NO_LOCAL = true;

	//std::string clientUser  { CLIENT_ID },
				//clientTopic { PUBLISH_TOPIC };

	// LWT message is broadcast to other users if out connection is lost
	auto lwt = mqtt::message(PUBLISH_TOPIC, "<<<" + CLIENT_ID + " was disconnected>>>", QOS, false);

	// Set up the connect options
	auto connOpts = mqtt::connect_options_builder()
		.keep_alive_interval(std::chrono::seconds(20))
		.automatic_reconnect(true)		//reconnect when connection lost
		.mqtt_version(MQTTVERSION_5)	//MQTT V5
		.clean_start(true)
		.will(std::move(lwt))			//add LWT message
		.finalize();

	//setup client
	mqtt::async_client cli(SERVER_ADDRESS, "", mqtt::create_options(MQTTVERSION_5));

	//callback functions
	cli.set_connection_lost_handler([](const std::string&) {
		LOG_F(INFO, "Connection to MQTT broker lost!");
		LOG_F(INFO, "Trying to reconnect...");
	});

	cli.set_connected_handler([](const std::string&) {
		LOG_F(INFO, "Connection to MQTT broker established!");
	});

	//publish to topic
	mqtt::topic topicSett{cli, PUBLISH_TOPIC, QOS};
	mqtt::topic topicHb{cli, HEARTBEAT_TOPIC, QOS};

	//start connection
	try {
		LOG_F(INFO, "Connecting to MQTT broker at %s to publish...", SERVER_ADDRESS.c_str());
		auto tok = cli.connect(connOpts);
		tok->wait();
		auto subOpts = mqtt::subscribe_options(NO_LOCAL);	//options: NO_LOCAL (don't receive own messages)
		topicSett.subscribe(subOpts)->wait();	//setup data
		topicHb.subscribe(subOpts)->wait();		//heartbeats
		LOG_F(INFO, "Publisher connected!");
	}
	catch (const mqtt::exception& exc) {
		LOG_F(ERROR, "Not able to connect publisher!");
		//return 1;
	}

	//collect messages to publish from queue
	while(1) {
		//TODO: check locking
		//std::unique_lock<std::mutex> lck{mut};
		//cond.wait(lck);

		if(mode == "Teacher" && msgQueueQuality.size() > 0) {
			MessageModels::QualityMessage qualMsg = msgQueueQuality.front();
			msgQueueQuality.pop();
			rapidjson::StringBuffer msgBuffer;
			rapidjson::Writer<rapidjson::StringBuffer> usrMsg(msgBuffer);
			qualMsg.Serialize(&usrMsg); 
			LOG_F(INFO, "Sending message: %s", msgBuffer.GetString());
			topicSett.publish(msgBuffer.GetString());
			//lck.unlock();
			//sleep(5);
		}
		else if(mode == "Student" && msgQueueSettings.size() > 0) {
			MessageModels::SettingsMessage settMsg = msgQueueSettings.front();
			msgQueueSettings.pop();
			rapidjson::StringBuffer msgBuffer;
			rapidjson::Writer<rapidjson::StringBuffer> usrMsg(msgBuffer);
			settMsg.Serialize(&usrMsg); 
			LOG_F(INFO, "Sending message: %s", msgBuffer.GetString());
			topicSett.publish(msgBuffer.GetString());
			//lck.unlock();
			//sleep(5);
		}
		else if(msgQueueHeartbeats.size() > 0) {
			std::string heartbeatMsg = msgQueueHeartbeats.front();
			msgQueueHeartbeats.pop();
			LOG_F(INFO, "Sending heartbeat: %s", heartbeatMsg.c_str());
			topicHb.publish(heartbeatMsg);
		}
	}
}


void mqtt_startSubscriber() {
	std::string SERVER_ADDRESS = conf.mqtt_broker;
	std::string CLIENT_ID = conf.mqtt_clientid;
	std::string SUBSCRIBE_TOPIC = conf.mqtt_subscribe_topic;
	std::string HEARTBEAT_TOPIC = "HB";
	const int QOS = conf.mqtt_qos;
	const bool NO_LOCAL = true;

	//LWT message is broadcast to other users if out connection is lost
	auto lwt = mqtt::message(SUBSCRIBE_TOPIC, "<<<" + CLIENT_ID + " was disconnected>>>", QOS, false);

	//connection options
	auto connOpts = mqtt::connect_options_builder()
		.keep_alive_interval(std::chrono::seconds(20))
		.automatic_reconnect(true)
		.mqtt_version(MQTTVERSION_5)
		.clean_start(true)
		.will(std::move(lwt))
		.finalize();

	mqtt::async_client cli(SERVER_ADDRESS, "", mqtt::create_options(MQTTVERSION_5));

	//callback functions
	cli.set_connection_lost_handler([](const std::string&) {
		LOG_F(INFO, "Connection to MQTT broker lost!");
		LOG_F(INFO, "Trying to reconnect...");
	});

	cli.set_connected_handler([](const std::string&) {
		LOG_F(INFO, "Connection to MQTT broker established!");
	});

	// Set the callback for incoming messages
	if(mode == "Teacher") {
		cli.set_message_callback([](mqtt::const_message_ptr msg) {
			std::string HEARTBEAT_TOPIC = "HB";
			std::string SUBSCRIBE_TOPIC = conf.mqtt_subscribe_topic;

			//logging
			LOG_F(INFO, "Message received: ");
			LOG_F(INFO, msg->get_payload_str().c_str());

			//LOG_F(ERROR, "Topic: %s", msg->get_topic().c_str());

			//check which topic received
			if(msg->get_topic() == HEARTBEAT_TOPIC && msg->get_payload_str() == "HEARTBEAT_ACK") {
				//LOG_F(INFO, "Heartbeat ACK received!");
				std::lock_guard<std::mutex> lck(mutHB);
				heartbeatReady = true;
				condHB.notify_all();
			}
			else if(msg->get_payload_str() == "HEARTBEAT") {}
			else if(msg->get_topic() == SUBSCRIBE_TOPIC) {
				MessageModels::SettingsMessage incMsg;
				incMsg.Deserialize(msg->get_payload_str());

				//copy settings over
				settMsg.FrequencyActive(incMsg.FrequencyActive());
				settMsg.FrequencyOne(incMsg.FrequencyOne());
				settMsg.FrequencyTwo(incMsg.FrequencyTwo());
				settMsg.PushToTalk(incMsg.PushToTalk());
				settMsg.Mode(incMsg.Mode());

				//display on screen
				DisplayHandler::updateDisplay();
			}
			else {
				LOG_F(ERROR, "Unknown topic received: %s", msg->get_topic().c_str());
			}
		});
	}
	else if(mode == "Student") {
		cli.set_message_callback([](mqtt::const_message_ptr msg) {
			const std::string HEARTBEAT_TOPIC = "HB";
			std::string SUBSCRIBE_TOPIC = conf.mqtt_subscribe_topic;

			//logging
			LOG_F(INFO, "Message received: ");
			LOG_F(INFO, msg->get_payload_str().c_str());

			//LOG_F(ERROR, "Topic: %s", msg->get_topic().c_str());

			if(msg->get_topic() == "HB" && msg->get_payload_str() == "HEARTBEAT") {
				//LOG_F(INFO, "Heartbeat received!");
				std::lock_guard<std::mutex> lck(mutHB);
				heartbeatReady = true;
				//LOG_F(ERROR, "nach lock_guard");
				condHB.notify_all();
				//LOG_F(ERROR, "nach notify_all");
			}
			else if(msg->get_payload_str() == "HEARTBEAT_ACK") {}
			else if(msg->get_topic() == SUBSCRIBE_TOPIC) {
				MessageModels::QualityMessage incMsg;
				incMsg.Deserialize(msg->get_payload_str());
				qualMsg.QualityRating(incMsg.QualityRating());	//copy quality rating over

				//send quality changes to Pure Data
				sendPuredataMessage(incMsg.QualityRating());
			}
			else {
				LOG_F(ERROR, "Unknown topic received: %s", msg->get_topic().c_str());
			}
		});
	}
	

	//topics to publish/subscribe on
	mqtt::topic topicSett{cli, SUBSCRIBE_TOPIC, QOS};
	mqtt::topic topicHb{cli, HEARTBEAT_TOPIC, QOS};

	// Start the connection.
	try {
		LOG_F(INFO, "Connecting to MQTT broker for subscription at %s ...", SERVER_ADDRESS.c_str());
		auto tok = cli.connect(connOpts);
		tok->wait();
		auto subOpts = mqtt::subscribe_options(NO_LOCAL);
		topicSett.subscribe(subOpts)->wait();
		topicHb.subscribe(subOpts)->wait();
		LOG_F(INFO, "Subscriber connected!");
	}
	catch (const mqtt::exception& exc) {
		LOG_F(ERROR, "Not able to connect subscriber!");
	}

	//running as thread, do not leave function
	while(1) {
		//no functionality
	}
}

void sendPuredataMessage(int rating) {
	std::string command;

	/* command contains the command string (a character array) */
	// set message content
	switch(rating) {
		case 5:
			command = conf.pd_q1factor;
			break;
		case 4:
			command = conf.pd_q2factor;
			break;
		case 3:
			command = conf.pd_q3factor;
			break;
		case 2:
			command = conf.pd_q4factor;
			break;
		case 1:
			command = conf.pd_q5factor;
			break;
		default:
			LOG_F(INFO, "Rating not 1 - 5!");
	}

	//using pure data internal send tool from bash
	LOG_F(INFO, "Command to send: %s!", command.c_str());
	system(command.c_str());
}

/**
 * not working, keep for legacy
 * */
/*void sendPuredataMessage(int rating) {
    int socketfd = -1, numSent = -1;
	float noisefactor = 0.0;
    sockaddr_in servaddr;
	char data[MSG_SIZE] = "nf 0";

    // make sure the port range is valid
    if(conf.pd_port < 0 || conf.pd_port > 65535)
    {
	    LOG_F(ERROR, "Invalid Pd Port!");
    } 	
	
    // create a UDP socket
    if((socketfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
    {
	    LOG_F(ERROR, "Unable to open socket to Pd!");
    }

    // clear the structure for the server address
    memset(&servaddr, 0, sizeof(servaddr));

    // populate the server address structure
    servaddr.sin_family = AF_INET;
	
    // initialize the IP address of the server
	LOG_F(INFO, "host: %s", conf.pd_host.c_str());
    if(!inet_pton(AF_INET, conf.pd_host.c_str(), &servaddr.sin_addr.s_addr))
    {
	    LOG_F(ERROR, "Unable to set IP Address for Pd!");
    }

    // set the port
    servaddr.sin_port = htons(conf.pd_port);

	LOG_F(INFO, "Rating received: %d", rating);

	// set message content
	switch(rating) {
		case 1:
			noisefactor = conf.pd_q1factor;
			break;
		case 2:
			noisefactor = conf.pd_q2factor;
			break;
		case 3:
			noisefactor = conf.pd_q3factor;
			break;
		case 4:
			noisefactor = conf.pd_q4factor;
			break;
		case 5:
			noisefactor = conf.pd_q5factor;
			break;
		default:
			LOG_F(INFO, "rating not 1-5");
	}
	sprintf(data, "nf %f", noisefactor);

    // send the time to the client
    if((numSent = sendto(socketfd, data, strlen(data)+1, 0, (sockaddr *)&servaddr, sizeof(servaddr))) < 0) {
	    LOG_F(ERROR, "Could not send Noise Factor message to Pure Data!");
    }
	else {
		LOG_F(INFO, "Sent Noise Factor Message %f to Pure Data!", noisefactor);
	}
}*/