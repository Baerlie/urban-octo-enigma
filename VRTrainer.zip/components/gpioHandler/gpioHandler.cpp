#include "gpioHandler.hpp"

//global variables
extern std::queue<MessageModels::SettingsMessage> msgQueueSettings;
extern std::queue<MessageModels::QualityMessage> msgQueueQuality;
extern std::condition_variable condMQ;
extern std::mutex mutMQ;
extern MessageModels::QualityMessage qualMsg;
extern MessageModels::SettingsMessage settMsg;
extern SFT::Config conf;

//functions
void setupTeacherGPIO() {
    //activate gpio pins   
    gpioSetMode(conf.pin_led, PI_OUTPUT);
    gpioWrite(conf.pin_led, 1);

    gpioSetMode(conf.sw_ptt, PI_INPUT);
    gpioSetISRFunc(conf.sw_ptt, EITHER_EDGE, 1000, &teacherPttBtnPushed);

    gpioSetMode(conf.sw_quality_0, PI_INPUT);
    gpioSetISRFunc(conf.sw_quality_0, EITHER_EDGE, 1000, &teacherQualityChange);

    gpioSetMode(conf.sw_quality_1, PI_INPUT);
    gpioSetISRFunc(conf.sw_quality_1, EITHER_EDGE, 1000, &teacherQualityChange);

    gpioSetMode(conf.sw_quality_2, PI_INPUT);
    gpioSetISRFunc(conf.sw_quality_2, EITHER_EDGE, 1000, &teacherQualityChange);

    gpioSetMode(conf.sw_quality_3, PI_INPUT);
    gpioSetISRFunc(conf.sw_quality_3, EITHER_EDGE, 1000, &teacherQualityChange);

    gpioSetMode(conf.sw_quality_4, PI_INPUT);
    gpioSetISRFunc(conf.sw_quality_4, EITHER_EDGE, 1000, &teacherQualityChange);

    gpioSetMode(conf.sw_mode_aero, PI_INPUT);
    gpioSetISRFunc(conf.sw_mode_aero, EITHER_EDGE, 1000, &aeroOn);

    gpioSetMode(conf.sw_mode_naut, PI_INPUT);
    gpioSetISRFunc(conf.sw_mode_naut, EITHER_EDGE, 1000, &nautOn);

    //keep thread running, otherwise ISR are lost
    while(1){ }
}

void setupStudentGPIO() {
    //activate gpio pins    
    gpioSetMode(conf.pin_led, PI_OUTPUT);
    gpioWrite(conf.pin_led, 1);

    gpioSetMode(conf.sw_ptt, PI_INPUT);
    gpioSetISRFunc(conf.sw_ptt, EITHER_EDGE, 1000, &studentPttBtnPushed);

    //gpioSetMode(conf.btn_freq, PI_INPUT);
    //gpioSetISRFunc(conf.btn_freq, EITHER_EDGE, 1000, &studentFreqBtnPushed);
    gpioSetMode(conf.sw_freq1, PI_INPUT);
    gpioSetISRFunc(conf.sw_freq1, EITHER_EDGE, 1000, &freq1On);
    gpioSetMode(conf.sw_freq2, PI_INPUT);
    gpioSetISRFunc(conf.sw_freq2, EITHER_EDGE, 1000, &freq2On);

    gpioSetMode(conf.sw_mode_aero, PI_INPUT);
    gpioSetISRFunc(conf.sw_mode_aero, EITHER_EDGE, 1000, &aeroOn);

    gpioSetMode(conf.sw_mode_naut, PI_INPUT);
    gpioSetISRFunc(conf.sw_mode_naut, EITHER_EDGE, 1000, &nautOn);

    //rotary encoder
    re_decoder decInn(conf.enc_inn_freq_l, conf.enc_inn_freq_r, rotaryCallbackInn);
    re_decoder decOut(conf.enc_out_freq_l, conf.enc_out_freq_r, rotaryCallbackOut);

    //keep thread running, otherwise ISR are lost
    while(1){ }
}

int studentEncBtnFreqPushed() {
    cout << "Student Enc Freq pushed! \n";
    return 0;
}

void studentPttBtnPushed(int gpio, int level, uint32_t tick) {
    static int level_old = 1;
    if (level == 1 && level_old == 0) {
        cout << "PTT interrupt received - UP!\n";
        level_old = 1;
        settMsg.PushToTalk(level);
        sendSettingsMessage();
        DisplayHandler::updateDisplay();
    } else if (level == 0 && level_old == 1) {
        cout << "PTT interrupt received - DOWN!\n";
        level_old = 0;
        settMsg.PushToTalk(level);
        sendSettingsMessage();
        DisplayHandler::updateDisplay();
    }
}

void studentFreqBtnPushed(int gpio, int level, uint32_t tick) {
    cout << "Student Freq Button pushed! \n";
    //return 0;
}

void teacherPttBtnPushed(int gpio, int level, uint32_t tick) {
    static int level_old = 1;
    if (level == 1 && level_old == 0) {
        cout << "PTT interrupt received - UP!\n";
        level_old = 1;
        qualMsg.PushToTalk(level);
        DisplayHandler::updateDisplay();
    } else if (level == 0 && level_old == 1) {
        cout << "PTT interrupt received - DOWN!\n";
        level_old = 0;
        qualMsg.PushToTalk(level);
        DisplayHandler::updateDisplay();
    }
}

void aeroOn(int gpio, int level, uint32_t tick) {
    static int level_old = 0;
    if (level == 1 && level_old == 0) {
        level_old = 1;
    } else if (level == 0 && level_old == 1) {
        cout << "Aero interrupt received - DOWN!\n";
        level_old = 0;
        settMsg.Mode(AERO);
        settMsg.FrequencyOne(AERO_LOWER);
        settMsg.FrequencyTwo(AERO_UPPER);
        DisplayHandler::updateDisplay();
        
        if(mode == "Student")
            sendSettingsMessage();
    }
}

void nautOn(int gpio, int level, uint32_t tick) {
    static int level_old = 0;
    if (level == 1 && level_old == 0) {
        level_old = 1;
    } else if (level == 0 && level_old == 1) {
        cout << "Naut interrupt received - DOWN!\n";
        level_old = 0;
        settMsg.FrequencyOne(NAUT_LOWER);
        settMsg.FrequencyTwo(NAUT_UPPER);
        settMsg.Mode(NAUT);
        DisplayHandler::updateDisplay();
        
        if(mode == "Student")
            sendSettingsMessage();
    }
}

void freq1On(int gpio, int level, uint32_t tick) {
    static int level_old = 0;
    if (level == 1 && level_old == 0) {
        level_old = 1;
    } else if (level == 0 && level_old == 1) {
        cout << "Freq1 interrupt received - DOWN!\n";
        level_old = 0;
        settMsg.FrequencyActive(1);
        sendSettingsMessage();
        DisplayHandler::updateDisplay();
    }    
}

void freq2On(int gpio, int level, uint32_t tick) {
    static int level_old = 0;
    if (level == 1 && level_old == 0) {
        level_old = 1;
    } else if (level == 0 && level_old == 1) {
        cout << "Freq2 interrupt received - DOWN!\n";
        level_old = 0;
        settMsg.FrequencyActive(2);
        sendSettingsMessage();
        DisplayHandler::updateDisplay();
    }
}

/**
 * 
 */
void teacherQualityChange(int gpio, int level, uint32_t tick) {
    int qual = 0;
    static int level_old = 0;

    if(gpio == conf.sw_quality_0)
        qual = 5;
    else if(gpio == conf.sw_quality_1)
        qual = 4;
    else if(gpio == conf.sw_quality_2)
        qual = 3;
    else if(gpio == conf.sw_quality_3)
        qual = 2;
    else if(gpio == conf.sw_quality_4)
        qual = 1;
    else {}

    if (level == 1 && level_old == 0) {
        level_old = 1;
    } else if (level == 0 && level_old == 1) {
        LOG_F(INFO, "Quality interrupt received - DOWN!");
        LOG_F(INFO, "ON Pin %d => Quality %d!", gpio, qual);
        qualMsg.QualityRating(qual);
        sendQualityMessage();
        DisplayHandler::updateDisplay();
        level_old = 0;
    }
}

int readFromPin(int pinNr) {
    return gpioRead(pinNr);
}

void rotaryCallbackInn(int way)
{
    float amnt;

    switch(settMsg.Mode()) {
        case AERO:
            amnt = AERO_STEPS;

            //down
            if(way > 0)
                amnt *= -1;

            if(settMsg.FrequencyActive() == 2) {
                settMsg.FrequencyOne(settMsg.FrequencyOne() + amnt);

                //check frequency, if too low
                if(settMsg.FrequencyOne() <= AERO_LOWER)
                    settMsg.FrequencyOne(AERO_LOWER);

                //check frequency, if too high
                if(settMsg.FrequencyOne() >= AERO_UPPER)
                    settMsg.FrequencyOne(AERO_UPPER);     
            }
            else if(settMsg.FrequencyActive() == 1) {
                settMsg.FrequencyTwo(settMsg.FrequencyTwo() + amnt);

                //check frequency, if too low
                if(settMsg.FrequencyTwo() <= AERO_LOWER)
                    settMsg.FrequencyTwo(AERO_LOWER);

                //check frequency, if too high
                if(settMsg.FrequencyTwo() >= AERO_UPPER)
                    settMsg.FrequencyTwo(AERO_UPPER);
            }
            else {
                //nothing to do
            }
            break;
        case NAUT:
            amnt = NAUT_STEPS;
            if(way < 0)
                amnt *= -1;

            if(settMsg.FrequencyActive() == 2) {
                settMsg.FrequencyOne(settMsg.FrequencyOne() + amnt);

                //check frequency, if too low
                if(settMsg.FrequencyOne() <= NAUT_LOWER)
                    settMsg.FrequencyOne(NAUT_LOWER); 

                //check frequency, if too high
                if(settMsg.FrequencyOne() >= NAUT_UPPER)
                    settMsg.FrequencyOne(NAUT_UPPER);   
                
                //check if frequ. between standard
                if(settMsg.FrequencyOne() >= NAUT_NO_LOWER && settMsg.FrequencyOne() <= NAUT_NO_UPPER)
                    settMsg.FrequencyOne(NAUT_NO_UPPER + NAUT_STEPS);
            }
            else if(settMsg.FrequencyActive() == 1) {
                settMsg.FrequencyTwo(settMsg.FrequencyTwo() + amnt);

                //check frequency, if too low
                if(settMsg.FrequencyTwo() <= NAUT_LOWER)
                    settMsg.FrequencyTwo(NAUT_LOWER); 

                //check frequency, if too high
                if(settMsg.FrequencyTwo() >= NAUT_UPPER)
                    settMsg.FrequencyTwo(NAUT_UPPER); 

                //check if frequ. between standard
                if(settMsg.FrequencyTwo() >= NAUT_NO_LOWER && settMsg.FrequencyTwo() <= NAUT_NO_UPPER)
                    settMsg.FrequencyTwo(NAUT_NO_UPPER + NAUT_STEPS);  
            }
            else {
                //nothing to do
            }
            break;
        default:
            break;
    }

    sendSettingsMessage();
    DisplayHandler::updateDisplay();
}

void rotaryCallbackOut(int way)
{
    float amnt;

    switch(settMsg.Mode()) {
        case AERO:
            amnt = 1;

            //down
            if(way > 0)
                amnt *= -1;

            if(settMsg.FrequencyActive() == 2) {
                settMsg.FrequencyOne(settMsg.FrequencyOne() + amnt);

                //check frequency, if too low
                if(settMsg.FrequencyOne() <= AERO_LOWER)
                    settMsg.FrequencyOne(AERO_LOWER);

                //check frequency, if too high
                if(settMsg.FrequencyOne() >= AERO_UPPER)
                    settMsg.FrequencyOne(AERO_UPPER);     
            }
            else if(settMsg.FrequencyActive() == 1) {
                settMsg.FrequencyTwo(settMsg.FrequencyTwo() + amnt);

                //check frequency, if too low
                if(settMsg.FrequencyTwo() <= AERO_LOWER)
                    settMsg.FrequencyTwo(AERO_LOWER);

                //check frequency, if too high
                if(settMsg.FrequencyTwo() >= AERO_UPPER)
                    settMsg.FrequencyTwo(AERO_UPPER);
            }
            else {
                //nothing to do
            }
            break;
        case NAUT:
            amnt = 1;
            if(way < 0)
                amnt *= -1;

            if(settMsg.FrequencyActive() == 2) {
                settMsg.FrequencyOne(settMsg.FrequencyOne() + amnt);

                //check frequency, if too low
                if(settMsg.FrequencyOne() <= NAUT_LOWER)
                    settMsg.FrequencyOne(NAUT_LOWER); 

                //check frequency, if too high
                if(settMsg.FrequencyOne() >= NAUT_UPPER)
                    settMsg.FrequencyOne(NAUT_UPPER);   
                
                //check if frequ. between standard
                if(settMsg.FrequencyOne() >= NAUT_NO_LOWER && settMsg.FrequencyOne() <= NAUT_NO_UPPER)
                    settMsg.FrequencyOne(NAUT_NO_UPPER + NAUT_STEPS);
            }
            else if(settMsg.FrequencyActive() == 1) {
                settMsg.FrequencyTwo(settMsg.FrequencyTwo() + amnt);

                //check frequency, if too low
                if(settMsg.FrequencyTwo() <= NAUT_LOWER)
                    settMsg.FrequencyTwo(NAUT_LOWER); 

                //check frequency, if too high
                if(settMsg.FrequencyTwo() >= NAUT_UPPER)
                    settMsg.FrequencyTwo(NAUT_UPPER); 

                //check if frequ. between standard
                if(settMsg.FrequencyTwo() >= NAUT_NO_LOWER && settMsg.FrequencyTwo() <= NAUT_NO_UPPER)
                    settMsg.FrequencyTwo(NAUT_NO_UPPER + NAUT_STEPS);  
            }
            else {
                //nothing to do
            }
            break;
        default:
            break;
    }

    sendSettingsMessage();
    DisplayHandler::updateDisplay();
}

void sendQualityMessage() {
    //create message for student client and push to queue
    std::lock_guard<std::mutex> lck {mutMQ};
    msgQueueQuality.push(qualMsg);
    condMQ.notify_all();
}

void sendSettingsMessage() {
    //create message for teacher client and push to queue
    std::lock_guard<std::mutex> lck {mutMQ};
    msgQueueSettings.push(settMsg);
    condMQ.notify_all();
}