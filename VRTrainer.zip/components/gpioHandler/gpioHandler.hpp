#ifndef SFT_GPIO_HANDLER_H
#define SFT_GPIO_HANDLER_H

#include <chrono>
#include <string>
#include <pigpio.h> // -lpigpio -lrt
#include <iostream>
#include <fstream>
#include <mutex>
#include <queue>
#include <condition_variable>
#include "../../ext/inipp/inipp.h"
#include "../../ext/loguru/loguru.hpp"
#include "../../ext/rotary/rotary_encoder.hpp"
#include "../../includes/jsonClasses/QualityMessage.hpp"
#include "../../includes/jsonClasses/SettingsMessage.hpp"
#include "../../includes/Config.hpp"
#include "../displayHandler/displayHandler.hpp"

using namespace std;
//using namespace GPIO;
using std::string;
using std::vector;
using std::cout;
using std::endl;

//externals
extern SFT::Config conf;
extern std::string mode;

//functions
int studentEncBtnFreqPushed();
int studentEncBtnFreqReleased();
void studentPttBtnPushed(int gpio, int level, uint32_t tick);
void studentFreqBtnPushed(int gpio, int level, uint32_t tick);
int studentFreqInnDialUp();
int studentFreqInnDialDown();
int studentFreqOutDialUp();
int studentFreqOutDialDown();
void teacherEncBtnPushed(int gpio, int level, uint32_t tick);
void teacherPttBtnPushed(int gpio, int level, uint32_t tick);
void teacherQualityChange(int gpio, int level, uint32_t tick);
void aeroOn(int gpio, int level, uint32_t tick);
void nautOn(int gpio, int level, uint32_t tick);
void freq1On(int gpio, int level, uint32_t tick);
void freq2On(int gpio, int level, uint32_t tick);
int teacherDialUp();
int teacherDialDown();
void setupTeacherGPIO();
void setupStudentGPIO();
void sendQualityMessage();
void sendSettingsMessage();
int readFromPin(int pinNr);
void rotaryCallbackInn(int way);
void rotaryCallbackOut(int way);

#endif  //SFT_GPIO_HANDLER_H