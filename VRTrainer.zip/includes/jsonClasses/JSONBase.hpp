//https://gotask.net/programming/serialize-and-deserialize-object-in-cpp-using-rapidjson/
#ifndef SFT_JSONBASE_H
#define SFT_JSONBASE_H

#include <string>
#include <fstream>
#include <sstream>
#include "../../ext/rapidjson/rapidjson.h"
#include "../../ext/rapidjson/document.h"		// rapidjson's DOM-style API
#include "../../ext/rapidjson/stringbuffer.h"	// wrapper of C stream for prettywriter as output
#include "../../ext/rapidjson/prettywriter.h"	// for stringify JSON

class JSONBase
{
    public:	
        bool DeserializeFromFile(const std::string& filePath);
        bool SerializeToFile(const std::string& filePath); 	

        virtual std::string Serialize() const;
        virtual bool Deserialize(const std::string& s);
        virtual bool Deserialize(const rapidjson::Value& obj) = 0;
        virtual bool Serialize(rapidjson::Writer<rapidjson::StringBuffer>* writer) const = 0;
    protected:	
        bool InitDocument(const std::string & s, rapidjson::Document &doc);
};

#endif