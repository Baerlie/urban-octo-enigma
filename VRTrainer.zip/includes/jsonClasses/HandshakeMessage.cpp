#include <string>
#include "HandshakeMessage.hpp"

namespace MessageModels
{
	HandshakeMessage::HandshakeMessage()
	{}

	HandshakeMessage::~HandshakeMessage()
	{}
	
	bool HandshakeMessage::Deserialize(const std::string& s)
	{
		rapidjson::Document doc;
		if(!InitDocument(s, doc))
			return false;
		
        Mode(doc["Mode"].GetString());
        IpAdress(doc["IpAddress"].GetString());

		return true;
	}

	bool HandshakeMessage::Deserialize(const rapidjson::Value & obj)
	{
		Mode(obj["Mode"].GetString());
		IpAdress(obj["IpAddress"].GetString());

		return true;
	}

	bool HandshakeMessage::Serialize(rapidjson::Writer<rapidjson::StringBuffer> * writer) const
	{
		writer->StartObject();
        writer->String("Mode");
        writer->String(_mode.c_str());
        writer->String("IpAddress");
        writer->String(_ipAddr.c_str());
		writer->EndObject();

		return true;
	}
}