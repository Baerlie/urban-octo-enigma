#include <string>
#include "../../includes/Config.hpp"
#include "SettingsMessage.hpp"

namespace MessageModels
{
	SettingsMessage::SettingsMessage() : _mode(AERO), _freq1(0.0f), _freq2(0.0f), _ptt(0)
	{}

	SettingsMessage::~SettingsMessage()
	{}

	bool SettingsMessage::Deserialize(const std::string& s)
	{
		rapidjson::Document doc;
		if(!InitDocument(s, doc))
			return false;
		
        FrequencyOne(doc["Freq#1"].GetDouble());
        FrequencyTwo(doc["Freq#2"].GetDouble());
        PushToTalk(doc["PTT"].GetInt());
        Mode(doc["Mode"].GetInt());
		FrequencyActive(doc["FreqActive"].GetInt());

		return true;
	}
	
	bool SettingsMessage::Deserialize(const rapidjson::Value & obj)
	{
		FrequencyOne(obj["Freq#1"].GetDouble());
        FrequencyTwo(obj["Freq#2"].GetDouble());
        PushToTalk(obj["PTT"].GetInt());
        Mode(obj["Mode"].GetInt());
		FrequencyActive(obj["FreqActive"].GetInt());

		return true;
	}

	bool SettingsMessage::Serialize(rapidjson::Writer<rapidjson::StringBuffer> * writer) const
	{
		writer->StartObject();
        writer->String("Freq#1");
        writer->Double(_freq1);
        writer->String("Freq#2");
        writer->Double(_freq2);
        writer->String("PTT");
        writer->Int(_ptt);
        writer->String("Mode");
        writer->Int(_mode);
		writer->String("FreqActive");
		writer->Int(_freqact);
		writer->EndObject();

		return true;
	}
}