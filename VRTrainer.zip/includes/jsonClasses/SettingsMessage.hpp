#ifndef SFT_JSON_SETTINGSMESSAGE_H
#define SFT_JSON_SETTINGSMESSAGE_H

#include "JSONBase.hpp"
#include <list>

namespace MessageModels {
	class SettingsMessage : public JSONBase {
        public:
            SettingsMessage();		
            virtual ~SettingsMessage();			
            virtual bool Deserialize(const rapidjson::Value& obj);
            virtual bool Deserialize(const std::string& s);
            virtual bool Serialize(rapidjson::Writer<rapidjson::StringBuffer>* writer) const;

            // Getters/Setters
            float FrequencyOne() const { return _freq1; }
		    void FrequencyOne(float freq1) { _freq1 = freq1; }
            float FrequencyTwo() const { return _freq2; }
		    void FrequencyTwo(float freq2) { _freq2 = freq2; }
            int PushToTalk() const { return _ptt; }
		    void PushToTalk(int ptt) { _ptt = ptt; }
            int Mode() const { return _mode; }
		    void Mode(int mode) { _mode = mode; }
            int FrequencyActive() const { return _freqact; }
            void FrequencyActive(int freqactive) { _freqact = freqactive; }

        private:
            float _freq1;
            float _freq2;
            int _ptt;
            int _freqact;
            int _mode;  //see Config.hpp for values
	};	
}

#endif  //SFT_JSON_SETTINGSMESSAGE_H
