#ifndef SFT_JSON_HANDSHAKEMESSAGE_H
#define SFT_JSON_HANDSHAKEMESSAGE_H

#include "JSONBase.hpp"
#include <list>

namespace MessageModels {
	class HandshakeMessage : public JSONBase {
        public:
            HandshakeMessage();		
            virtual ~HandshakeMessage();			
            virtual bool Deserialize(const std::string& s);
            virtual bool Deserialize(const rapidjson::Value& obj);
            virtual bool Serialize(rapidjson::Writer<rapidjson::StringBuffer>* writer) const;

            // Getters/Setters
            const std::string& Mode() const { return _mode; }
		    void Mode(const std::string& mode) { _mode = mode; }
            const std::string& IpAdress() const {return _ipAddr; }
            void IpAdress(const std::string& ipAddr) { _ipAddr = ipAddr; }

        private:
            std::string _mode;
            std::string _ipAddr;
	};	
}

#endif  //SFT_JSON_HANDSHAKEMESSAGE_H
