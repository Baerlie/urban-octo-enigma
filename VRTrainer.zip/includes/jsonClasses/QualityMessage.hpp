#ifndef SFT_JSON_QUALITYMESSAGE_H
#define SFT_JSON_QUALITYMESSAGE_H

#include "JSONBase.hpp"
#include <list>

namespace MessageModels {
	class QualityMessage : public JSONBase {
        public:
            QualityMessage();		
            virtual ~QualityMessage();			
            virtual bool Deserialize(const rapidjson::Value& obj);
            virtual bool Deserialize(const std::string& s);
            virtual bool Serialize(rapidjson::Writer<rapidjson::StringBuffer>* writer) const;

            // Getter/Setter
            int QualityRating() const {return _quality;}
            void QualityRating(const int& quality) { _quality = quality; }
            int PushToTalk() const { return _ptt; }
            void PushToTalk(int ptt) { _ptt = ptt; }

        private:
            int _quality;
            int _ptt;
	};	
}

#endif  //SFT_JSON_QUALITYMESSAGE_H