#include <string>
#include "QualityMessage.hpp"

namespace MessageModels
{
	QualityMessage::QualityMessage() : _quality(0)
	{}

	QualityMessage::~QualityMessage()
	{}
	
	bool QualityMessage::Deserialize(const std::string& s)
	{
		rapidjson::Document doc;
		if(!InitDocument(s, doc))
			return false;
		
        QualityRating(doc["quality"].GetInt());

		return true;
	}
	
	bool QualityMessage::Deserialize(const rapidjson::Value & obj)
	{
		QualityRating(obj["quality"].GetInt());
		return true;
	}

	bool QualityMessage::Serialize(rapidjson::Writer<rapidjson::StringBuffer> * writer) const
	{
		writer->StartObject();
        writer->String("quality");
        writer->Int(_quality);
		writer->EndObject();

		return true;
	}
}