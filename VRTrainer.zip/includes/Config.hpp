#ifndef SFT_CONFIG_H
#define SFT_CONFIG_H

#include <cstdlib>
#include <cstring>
#include <iostream>

namespace SFT {
    struct Config {
            int pin_led;
            int sw_ptt;
            int sw_mode_aero;
            int sw_mode_naut;
            int sw_quality_0;
            int sw_quality_1;
            int sw_quality_2;
            int sw_quality_3;
            int sw_quality_4;
            int mqtt_qos;
            int enc_inn_freq_l;
            int enc_inn_freq_r;
            int enc_out_freq_l;
            int enc_out_freq_r;
            int sw_freq1;
            int sw_freq2;
            int pd_port;
            std::string pd_q1factor;
            std::string pd_q2factor;
            std::string pd_q3factor;
            std::string pd_q4factor;
            std::string pd_q5factor;
            std::string mqtt_broker;
            std::string mqtt_clientid;
            std::string mqtt_publish_topic;
            std::string mqtt_subscribe_topic;
            std::string file_log;
            std::string host_ip;
            std::string client_ip;
            std::string mqtt_heartbeat_topic;
            std::string pd_message;
            std::string pd_host;
    };
}

#define AERO_UPPER  137.000
#define AERO_LOWER  117.975
#define AERO 0
#define NAUT 1
#define NAUT_UPPER 88
#define NAUT_LOWER 1
#define NAUT_NO_UPPER 59    //no channels between 28 and 60
#define NAUT_NO_LOWER 29
#define AERO_STEPS 0.005
#define NAUT_STEPS 1
#define APP_VERSION 1.0

#endif  //SFT_CONFIG_H