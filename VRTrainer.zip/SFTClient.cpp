#include "SFTClient.hpp"

//global variables
std::queue<MessageModels::SettingsMessage> msgQueueSettings;
std::queue<MessageModels::QualityMessage> msgQueueQuality;
std::queue<std::string> msgQueueHeartbeats;
MessageModels::QualityMessage qualMsg;
MessageModels::SettingsMessage settMsg;
RtAudio audio;
SFT::CircularBuffer<AudioFrame> playbackBuffer(CIRCULAR_BUFFER_SIZE);
SFT::CircularBuffer<AudioFrame> transferBuffer(CIRCULAR_BUFFER_SIZE);
SFT::Config conf;
std::condition_variable condMQ, condHB, condTx;
std::mutex mutMQ, mutHB, mutTx;
std::string mode;
bool disconnected, heartbeatReady, playback = false, timeout = true;
int fdDisplay, handshakeOk, heartbeatTimeouts, txReady = 0;
//TODO: two condition variables, two mutex variables (one for each queue)
char *outputBuffer;

int main(int argc, char *argv[]) {
  std::promise<void> exitSignalStartup, exitSignalConnecting, exitSignalRuntime, exitSignalGPIO;

  //read startup config
  int startup = readStartupConfig();
  if(startup < 0) {
    LOG_F(ERROR, "Error reading startup config!");
    return EXIT_FAILURE;
  }

  //init logging
  loguru::init(argc, argv); 
  loguru::add_file(conf.file_log.c_str(), loguru::Truncate, loguru::Verbosity_INFO);  // Only log INFO, WARNING, ERROR and FATAL

  //initialize gpio access
  int status = gpioInitialise();
  if(status == PI_INIT_FAILED) {
    LOG_F(ERROR, "Error initializing GPIO library!");
    return EXIT_FAILURE;
  }
  else {
    LOG_F(INFO, "GPIO library initialized!");
  }

  gpioSetMode(conf.pin_led, PI_HIGH);  //LED on

  //setup signal handler
  signal(SIGINT, signalHandler);
  signal(SIGSEGV, signalHandler);
  //TODO: add more
  
  //init display
  int displ = initDisplay();
  if(displ < 0) {
    LOG_F(ERROR, "Error initializing LCD!");
  }

  //init circular buffers
  transferBuffer.reset();
  playbackBuffer.reset();

  //display startup procedure
  std::future<void> futureStartup = exitSignalStartup.get_future();
  std::thread tStartup(&startupDisplayThread, std::move(futureStartup));  

  //teacher or student machine?
  std::string localIP = getLocalIP();
  if(localIP == conf.host_ip) {
    mode = "Teacher";
  }
  else {
    mode = "Student";
    conf.client_ip = localIP;
  }
  
  LOG_F(INFO, "Starting up client: %s", mode.c_str());
  LOG_F(INFO, "OK!");

  //load config to global variable
  int confSucc = readModeConfig(mode);
  if(confSucc < 0) {
    LOG_F(ERROR, "Error loading config!");
    return EXIT_FAILURE;
  }
  
  //setup GPIO handler
  LOG_F(INFO, "Setting up GPIO thread...");
  std::future<void> futureGPIO = exitSignalGPIO.get_future();
  std::thread tGPIO(&runtimeGPIOThread, std::move(futureGPIO));
  LOG_F(INFO, "OK!");

  //"Pfui", wait for 5 seconds to get GPIO up and running
  sleep(5);
  exitSignalStartup.set_value();  //setup done, stop display thread  
  tStartup.join();                //wait to finish

  //messages setup
  int msgSetup = setupMessages();
  if(msgSetup < 0) {
    LOG_F(ERROR, "Setup not successful!");
    return EXIT_FAILURE;
  }

  //connection display
  std::future<void> futureConnecting = exitSignalConnecting.get_future();
  std::thread tConnection(&connectionDisplayThread, std::move(futureConnecting));
  sleep(5);   //TODO: REMOVE!!!!  
  //handshaking
  handshakeOk = -1;
  handshakeConnection();
  exitSignalConnecting.set_value();
  tConnection.join(); //wait to finish
  disconnected = false;

  //setup MQTTClient connections
  LOG_F(INFO, "Starting Publisher/Subscriber...");
  std::thread tPublisher(mqtt_startPublisher);
  std::thread tSubscriber(mqtt_startSubscriber);
  sleep(5);   //wait until both devices connected to MQTT
  //TODO: runtime cancel futures

  //start heartbeats
  //std::thread tHeartbeats(startHeartbeats);

  //send first setup messages
  sendSetupMessage();

  //reset display
  DisplayHandler::clearDisplay();
  DisplayHandler::updateDisplay();

  //setup Audio
  std::thread tAudioPlayback(audioPlayback);
  std::thread tAudioTransfer(audioTransfer);

  //collect thread joins
  tPublisher.join();
  tSubscriber.join();
  //tHeartbeats.join();
  tGPIO.join();
  tAudioPlayback.join();
  tAudioTransfer.join();
}


// Audio functions

int streamInOut( void *outputBuffer, void *inputBuffer, unsigned int /*nBufferFrames*/, double /*streamTime*/, RtAudioStreamStatus status, void *data )
{
  if (status) 
      std::cout << "Stream over/underflow detected." << std::endl;
  
  AudioFrame frameData;
  unsigned int *bytes = static_cast<unsigned int*>(data);
  
  memcpy(frameData.frameData, static_cast<opus_int16*>(inputBuffer), *bytes);
  frameData.size = sizeof(inputBuffer);
  
  if(!transferBuffer.full()) {
    transferBuffer.put(frameData);
  }
  else {
    LOG_F(INFO, "Transfer buffer full!");
  }

  if(playback == false && (playbackBuffer.empty() || playbackBuffer.size() < BUFFER_MAX_SIZE)) {
    LOG_F(INFO, "Playback buffer too small, refilling...");
    playback = false;
  }
  else if(playbackBuffer.size() >= BUFFER_MIN_SIZE) {
    playback = true;
  }
  else if(playbackBuffer.empty()) {
    playback = false;
  }

  //check buffer size, stop playback if less than min. size
  if(playback) {
    //LOG_F(INFO, "Writing to headset output buffer!");
    memcpy(outputBuffer, playbackBuffer.get().frameData, *bytes);   //copy decoded audio values to output buffer
  }
  
  //lock and notify
  std::lock_guard<std::mutex> lck(mutTx);
  txReady = 1;
  condTx.notify_one();

  return 0;
}

int audioTransfer() {
  uvg_rtp::context ctx;
  uvg_rtp::session *sess;
  uvg_rtp::media_stream *snd, *rcv;
  OpusEncoder *enc;
  opus_int32 res;
  int error = 0;

  //RTP setup
  if(mode == "Teacher")
    sess = ctx.create_session(conf.client_ip);
  else if(mode == "Student")
    sess = ctx.create_session(conf.host_ip);
  else
    sess = ctx.create_session("127.0.0.1");   //loopback
  
  snd = sess->create_stream(8888, 8889, RTP_FORMAT_OPUS, 0);
  rcv = sess->create_stream(8889, 8888, RTP_FORMAT_OPUS, 0);
  rcv->install_receive_hook(nullptr, &receiveAudio);

  if(!snd)
    LOG_F(ERROR, "Could not create send stream!");
  if(!rcv)
    LOG_F(ERROR, "Could not create receive stream!");

  //OPUS encoder
  enc = opus_encoder_create(SAMPLE_RATE, CHANNELS, APPLICATION, &error);
  if(error < 0) {
      std::cout << "failed to create an encoder: " << opus_strerror(error) << std::endl;
      return EXIT_FAILURE;
  }
  else {
    std::cout << "Encoder Created: " << opus_strerror(error) << std::endl;
  }
  error = opus_encoder_ctl(enc, OPUS_SET_BITRATE(BITRATE));
  error = opus_encoder_ctl(enc, OPUS_SET_COMPLEXITY(COMPLEXITY));
  error = opus_encoder_ctl(enc, OPUS_SET_SIGNAL(OPUS_SIGNAL_VOICE));
  if(error < 0) {
      std::cout << "failed to set bitrate: " << opus_strerror(error) << std::endl;
      return EXIT_FAILURE;
  }
  else {
    std::cout << "Bitrate set: " << opus_strerror(error) << std::endl;
  }

  //transfer forever
  while(1) {
    //wait for lock
    //retrieve next from transfer buffer into encoder buffer
    //transfer all buffer entries at once
    std::unique_lock<std::mutex> lck(mutTx);
    condTx.wait(lck, []{return txReady == 1;});
    txReady = 0;

    if(!transferBuffer.empty()) {
      opus_int16 encBuffer[FRAME_SIZE*CHANNELS*2];
      unsigned char sendBuffer[MAX_PACKET_SIZE];
      memcpy(encBuffer, transferBuffer.get().frameData, 1920);    //TODO: remove hardcoded

      res = opus_encode(enc, encBuffer, FRAME_SIZE, sendBuffer, MAX_PACKET_SIZE);
      if(res < 0)
          std::cout << "Error encoding frames!" << opus_strerror(res) << std::endl;

      //send audio frame to cpt
      res = snd->push_frame(sendBuffer, FRAME_SIZE, RTP_COPY);
      if(res < 0)
        std::cout << "Error pushing frames!" << opus_strerror(res) << std::endl;
    }
  }
}

void receiveAudio(void *arg, uvgrtp::frame::rtp_frame *frame) {
  OpusDecoder *decoder;
  AudioFrame audioFrame;
  opus_int16 decBuffer[MAX_FRAME_SIZE*CHANNELS];
  int frame_size, error = 0;

  //create OPUS decoder
  decoder = opus_decoder_create(SAMPLE_RATE, CHANNELS, &error);
  if (error < 0)  {
    LOG_F(ERROR, "Failed to create OPUS decoder: %s", opus_strerror(error));
    return;   //exit
  }

  //receive audio frame from cpt
  //use buffer to ensure output without interruptions
  frame_size = opus_decode(decoder, frame->payload, frame->payload_len, decBuffer, MAX_FRAME_SIZE, 0);
  if(frame_size < 0)
      LOG_F(ERROR, "Error decoding frame!");

  //push to playback buffer
  if(!playbackBuffer.full()) {
    memcpy(audioFrame.frameData, decBuffer, sizeof(decBuffer));
    audioFrame.size = sizeof(decBuffer);
    playbackBuffer.put(audioFrame);
  }
  else {
    LOG_F(INFO, "Playback buffer full!");
  }

  (void)uvgrtp::frame::dealloc_frame(frame);
}

int audioPlayback() {
  RtAudio::StreamParameters iParams, oParams;
  RtAudio::StreamOptions options;  
  unsigned int iOffset = 0, oOffset = 0, bufferBytes, bufferFrames = FRAME_SIZE;

  LOG_F(INFO, "device count: %d", audio.getDeviceCount());
  
  //won't happen on RPi (has built in audio device), but to make sure...
  if (audio.getDeviceCount() < 1 ) {
    LOG_F(ERROR, "No audio devices found!");
    exit(1);
  }

  //output all devices on system
  for(int i=0; i<audio.getDeviceCount(); i++) {
    RtAudio::DeviceInfo devInfo = audio.getDeviceInfo(i);
    LOG_F(INFO, devInfo.name.c_str());
  }

  // Let RtAudio print messages to stderr.
  audio.showWarnings(true);

  // set devices for different modes
  if(mode == "Student") {
    // student: virtual output device
    iParams.deviceId = 4;
    oParams.deviceId = 2;
  }
  else {
    // teacher: same output device as input
    iParams.deviceId = 2;
    oParams.deviceId = 2;
  }

  // Set the same number of channels for both input and output, audio options    
  iParams.nChannels = 1;
  iParams.firstChannel = iOffset;  
  oParams.nChannels = 1;
  oParams.firstChannel = oOffset;  
  options.flags = RTAUDIO_SCHEDULE_REALTIME;
  options.flags |= RTAUDIO_NONINTERLEAVED;
  options.flags |= RTAUDIO_MINIMIZE_LATENCY;
  options.flags |= RTAUDIO_HOG_DEVICE;
  options.priority = 1;

  bufferBytes = bufferFrames * CHANNELS * sizeof(BYTE_TYPE);
  outputBuffer = allocate_buffer();

  try {
    //gain access to audio device
    audio.openStream(&oParams, &iParams, FORMAT, SAMPLE_RATE, &bufferFrames, &streamInOut, (void *)&bufferBytes, &options);
  }
  catch ( RtAudioError& e ) {
    LOG_F(ERROR, "Error opening stream: %s", e.getMessage().c_str());
    exit( 1 );
  }

  //start actual streaming
  try {
    audio.startStream();
  }
  catch ( RtAudioError& e ) {
    std::cout << '\n' << e.getMessage() << '\n' << std::endl;
    goto cleanup;   //TODO!!!
  }

  while(1) { }  //running forever

  //TODO: do with signal handling
  cleanup:
  if (audio.isStreamOpen()) {
    audio.stopStream();
    audio.closeStream();
    //ctx.destroy_session(sess);
  }

  return 0;
}

char* allocate_buffer() {
  unsigned int size_of_one_frame = (snd_pcm_format_width(SND_PCM_FORMAT_S16_BE)/8) * CHANNELS;
  return (char*) calloc(FRAME_SIZE, size_of_one_frame);
}



//GPIO functions

int readQualityFromPins() {
  int pin_Q0, pin_Q1, pin_Q2, pin_Q3, pin_Q4, pin_Q5;

  //read from pins, return first which is 0 (pullup)
  inipp::Ini<char> ini;	
  std::ifstream is("config/teacher.conf");
  ini.parse(is);
  inipp::get_value(ini.sections["gpio"], "sw_quality_0", pin_Q0);
  inipp::get_value(ini.sections["gpio"], "sw_quality_1", pin_Q1);
  inipp::get_value(ini.sections["gpio"], "sw_quality_2", pin_Q2);
  inipp::get_value(ini.sections["gpio"], "sw_quality_3", pin_Q3);
  inipp::get_value(ini.sections["gpio"], "sw_quality_4", pin_Q4);
  inipp::get_value(ini.sections["gpio"], "sw_quality_5", pin_Q5);

  if(readFromPin(pin_Q0) == 0)
    return 5;
  else if(readFromPin(pin_Q1) == 0)
    return 4;
  else if(readFromPin(pin_Q2) == 0)
    return 3;
  else if(readFromPin(pin_Q3) == 0)
    return 2;
  else if(readFromPin(pin_Q4) == 0)
    return 1;
  else if(readFromPin(pin_Q5) == 0)
    return 1;
  else
    return -1;
}

int readModeFromPins() {
  int pin_F, pin_N;

  //read from pins, return first which is 0 (pullup)
  inipp::Ini<char> ini;	
  std::ifstream is("config/student.conf");
  ini.parse(is);
  inipp::get_value(ini.sections["gpio"], "sw_mode_aero", pin_F);
  inipp::get_value(ini.sections["gpio"], "sw_mode_naut", pin_N);

  if(readFromPin(pin_F) == 0)
    return AERO;
  else if(readFromPin(pin_N) == 0)
    return NAUT;
  else
    return -1;
}

int readFreqSelFromPins() {
  int pin_F1, pin_F2;

  //read from pins, return first which is 0 (pullup)
  inipp::Ini<char> ini;	
  std::ifstream is("config/student.conf");
  ini.parse(is);
  inipp::get_value(ini.sections["gpio"], "sw_freq1", pin_F1);
  inipp::get_value(ini.sections["gpio"], "sw_freq2", pin_F2);

  if(readFromPin(pin_F1) == 0)
    return 1;
  else if(readFromPin(pin_F2) == 0)
    return 2;
  else
    return -1;
}

//MQTT functions
int setupMessages() {
  LOG_F(INFO, "Starting setup...");
  int strt_mode = readModeFromPins();
  if(mode == "Teacher") {
    qualMsg.QualityRating(readQualityFromPins());
    settMsg.FrequencyActive(1);
  }
  else {
    qualMsg.QualityRating(0);
    settMsg.FrequencyActive(readFreqSelFromPins());
  }
  qualMsg.PushToTalk(1);

  if(strt_mode == AERO) {
    settMsg.FrequencyOne(AERO_LOWER);
    settMsg.FrequencyTwo(AERO_UPPER);
  }
  else if(strt_mode == NAUT) {
    settMsg.FrequencyOne(NAUT_LOWER);
    settMsg.FrequencyTwo(NAUT_UPPER);
  }
  settMsg.Mode(strt_mode);
  settMsg.PushToTalk(1);

  return 0;
}

//helpers 
std::string getLocalIP() {
  struct ifaddrs *ifaddr, *ifa;
  int s;
  char host[NI_MAXHOST];

    if (getifaddrs(&ifaddr) == -1)
    {
        perror("getifaddrs");
        exit(EXIT_FAILURE);
    }

    for (ifa = ifaddr; ifa != NULL; ifa = ifa->ifa_next)
    {
        if (ifa->ifa_addr == NULL)
            continue;  

        s = getnameinfo(ifa->ifa_addr,sizeof(struct sockaddr_in),host, NI_MAXHOST, NULL, 0, NI_NUMERICHOST);

        if((strcmp(ifa->ifa_name,"wlan0")==0)&&(ifa->ifa_addr->sa_family==AF_INET))
        {
            if (s != 0)
            {
                printf("getnameinfo() failed: %s\n", gai_strerror(s));
                exit(EXIT_FAILURE);
            }
        }
    }

    freeifaddrs(ifaddr);
    return host;
}

int readStartupConfig() {
  LOG_F(INFO, "Parsing config file...");
  inipp::Ini<char> ini;
  std::ifstream is("config/startup.conf");
  ini.parse(is);
  inipp::get_value(ini.sections["startup"], "host_ip", conf.host_ip);
  inipp::get_value(ini.sections["startup"], "file_log", conf.file_log);
  inipp::get_value(ini.sections["startup"], "mqtt_heartbeat_topic", conf.mqtt_heartbeat_topic);
  LOG_F(INFO, "Config parsed!");

  return 0;
}

int readModeConfig(std::string mode) {
  LOG_F(INFO, "Parsing logfile for mode %s...", mode.c_str());
  inipp::Ini<char> ini;	

  if(mode.compare("Teacher") == 0) {
    std::ifstream is("config/teacher.conf");
    ini.parse(is);
  }
  else {
    std::ifstream is("config/student.conf");
    ini.parse(is);
  }

  inipp::get_value(ini.sections["gpio"], "pin_led", conf.pin_led);
  inipp::get_value(ini.sections["gpio"], "sw_ptt", conf.sw_ptt);
  inipp::get_value(ini.sections["gpio"], "sw_mode_aero", conf.sw_mode_aero);
  inipp::get_value(ini.sections["gpio"], "sw_mode_naut", conf.sw_mode_naut);
  inipp::get_value(ini.sections["connections"], "mqtt_broker", conf.mqtt_broker);
  inipp::get_value(ini.sections["connections"], "mqtt_clientid", conf.mqtt_clientid);
  inipp::get_value(ini.sections["connections"], "mqtt_publish_topic", conf.mqtt_publish_topic);
  inipp::get_value(ini.sections["connections"], "mqtt_subscribe_topic", conf.mqtt_subscribe_topic);
  inipp::get_value(ini.sections["connections"], "mqtt_qos", conf.mqtt_qos);
  inipp::get_value(ini.sections["startup"], "file_log", conf.file_log);
  inipp::get_value(ini.sections["startup"], "host_ip", conf.host_ip);

  if(mode == "Teacher") {
    inipp::get_value(ini.sections["gpio"], "sw_quality_0", conf.sw_quality_0);
    inipp::get_value(ini.sections["gpio"], "sw_quality_1", conf.sw_quality_1);
    inipp::get_value(ini.sections["gpio"], "sw_quality_2", conf.sw_quality_2);
    inipp::get_value(ini.sections["gpio"], "sw_quality_3", conf.sw_quality_3);
    inipp::get_value(ini.sections["gpio"], "sw_quality_4", conf.sw_quality_4);
  }
  else {
    inipp::get_value(ini.sections["gpio"], "enc_inn_freq_l", conf.enc_inn_freq_l);
    inipp::get_value(ini.sections["gpio"], "enc_inn_freq_r", conf.enc_inn_freq_r);
    inipp::get_value(ini.sections["gpio"], "enc_out_freq_l", conf.enc_out_freq_l);
    inipp::get_value(ini.sections["gpio"], "enc_out_freq_r", conf.enc_out_freq_r);
    inipp::get_value(ini.sections["gpio"], "sw_freq1", conf.sw_freq1);
    inipp::get_value(ini.sections["gpio"], "sw_freq2", conf.sw_freq2);
    //inipp::get_value(ini.sections["gpio"], "btn_freq", conf.btn_freq);  //not used in software
    inipp::get_value(ini.sections["puredata"], "pd_host", conf.pd_host);
    inipp::get_value(ini.sections["puredata"], "pd_port", conf.pd_port);
    inipp::get_value(ini.sections["puredata"], "pd_message", conf.pd_message);
    inipp::get_value(ini.sections["puredata"], "pd_q1factor", conf.pd_q1factor);
    inipp::get_value(ini.sections["puredata"], "pd_q2factor", conf.pd_q2factor);
    inipp::get_value(ini.sections["puredata"], "pd_q3factor", conf.pd_q3factor);
    inipp::get_value(ini.sections["puredata"], "pd_q4factor", conf.pd_q4factor);
    inipp::get_value(ini.sections["puredata"], "pd_q5factor", conf.pd_q5factor);
  }

  LOG_F(INFO, "Done!");

  return 0;
}

int initDisplay() {
  fdDisplay = i2cOpen(1, I2C_ADDR, 0);
  lcd_init(); //display startup procedure
  ClrLcd(); //clear display
  return 0;
}



//thread functions
void startupDisplayThread(std::future<void> futureObj) {
    while (futureObj.wait_for(std::chrono::milliseconds(1)) == std::future_status::timeout)
    {
        DisplayHandler::displayStartup();
    }

    ClrLcd();
    //exit thread
}

void connectionDisplayThread(std::future<void> futureObj) {
    while (futureObj.wait_for(std::chrono::milliseconds(1)) == std::future_status::timeout)
    {
        DisplayHandler::displayConnecting();
    }

    ClrLcd();
    //exit thread
}

void runtimeGPIOThread(std::future<void> futureObj) {
    while (futureObj.wait_for(std::chrono::milliseconds(1)) == std::future_status::timeout)
    {
        if(mode == "Teacher")
          setupTeacherGPIO();
        else
          setupStudentGPIO();
    }

    DisplayHandler::clearDisplay();
    //exit thread
}

void signalHandler(int signum) {
  LOG_F(INFO, "Closing program!");
  gpioSetMode(conf.pin_led, PI_LOW);  //LED off
  DisplayHandler::clearDisplay();     //clear display
  gpioTerminate();                    //free GPIO
  LOG_F(INFO, "Exit! Signal: %d", signum);
  exit(signum);  
}

/**
 * not working, keep for legacy
 **/
int handshakeConnectionTeacher() {
  LOG_F(INFO, "Starting handshake procedure...");
  std::string SERVER_ADDRESS(conf.mqtt_broker);
  const int QOS = 1;
  const bool NO_LOCAL = true;
  std::string clientUser { conf.mqtt_clientid }, clientTopic { "HANDSHAKE" };
  auto lwt = mqtt::message(clientTopic, "<<<" + clientUser + " was disconnected>>>", QOS, false);

  //setup connection options
  auto connOpts = mqtt::connect_options_builder()
		.keep_alive_interval(std::chrono::seconds(20))
		.mqtt_version(MQTTVERSION_5)
		.clean_start(true)
		.will(std::move(lwt))
		.finalize();

  mqtt::async_client cli(SERVER_ADDRESS, "", mqtt::create_options(MQTTVERSION_5));

  // Set the callback for incoming messages
	cli.set_message_callback([](mqtt::const_message_ptr msg) {
		std::cout << "Message received: \n";
		std::cout << msg->get_payload_str() << std::endl;
    
    //check message, increase ok counter
    MessageModels::HandshakeMessage incMsg;
    //MessageModels::HandshakeMessage outMsg;
    //if (handshakeOk == -1) {   // awaiting REQ
      incMsg.Deserialize(msg->get_payload_str());

      if(incMsg.Mode() == "REQ") {
        handshakeOk = 0;
        conf.client_ip = incMsg.IpAdress();
      }
    //else if(handshakeOk == 1) {
      //incMsg.Deserialize(msg->get_payload_str());

      if(incMsg.Mode() == "REQOK")
        handshakeOk = 2;
    //}
	});

  mqtt::topic topic { cli, clientTopic, QOS };

  try {
		std::cout << "Connecting to the server at '" << SERVER_ADDRESS << "'..." << std::flush;
		auto tok = cli.connect(connOpts);
		tok->wait();
		// Subscribe to the topic using "no local" so that
		// we don't get own messages sent back to us
		std::cout << "Ok\nJoining the group..." << std::flush;
		auto subOpts = mqtt::subscribe_options(NO_LOCAL);
		topic.subscribe(subOpts)->wait();
		std::cout << "Ok" << std::endl;
	}
	catch (const mqtt::exception& exc) {
		std::cerr << "\nERROR: Unable to connect. "
			<< exc.what() << std::endl;
		//return 1;
	}

  rapidjson::StringBuffer msgBuffer;
  rapidjson::Writer<rapidjson::StringBuffer> usrMsg(msgBuffer);
  MessageModels::HandshakeMessage handshakeMsg;

  while(handshakeOk != 2) {
    //wait to finish handshake
    if(handshakeOk == 0) {
      handshakeMsg.IpAdress(getLocalIP());
      handshakeMsg.Mode("OK");
      handshakeMsg.Serialize(&usrMsg);
      std::cout << "sending message: " << msgBuffer.GetString() << "\n";
      topic.publish(msgBuffer.GetString());   //publish handshake answer
      //handshakeOk = 1;
    }

    gpioDelay(1000000);  //timeout before resending
  }

  cli.disconnect();   //disconnect

  LOG_F(INFO, "Handshake ok, continue!");
  return 0;
}

int handshakeConnectionStudent() {
  LOG_F(INFO, "Starting handshake procedure...");
  std::string SERVER_ADDRESS(conf.mqtt_broker);
  const int QOS = 1;
  const bool NO_LOCAL = true;
  std::string clientUser { conf.mqtt_clientid }, clientTopic { "HANDSHAKE" };
  auto lwt = mqtt::message(clientTopic, "<<<" + clientUser + " was disconnected>>>", QOS, false);

  //setup connection options
  auto connOpts = mqtt::connect_options_builder()
		.keep_alive_interval(std::chrono::seconds(20))
		.mqtt_version(MQTTVERSION_5)
		.clean_start(true)
		.will(std::move(lwt))
		.finalize();

  mqtt::async_client cli(SERVER_ADDRESS, "", mqtt::create_options(MQTTVERSION_5));

  // Set the callback for incoming messages
	cli.set_message_callback([](mqtt::const_message_ptr msg) {
		std::cout << "Message received: \n";
		std::cout << msg->get_payload_str() << std::endl;
    
    //check message, increase ok counter
    MessageModels::HandshakeMessage incMsg;
    //MessageModels::HandshakeMessage outMsg;
    //if (handshakeOk == 0) {   // awaiting OK
      incMsg.Deserialize(msg->get_payload_str());

      if(incMsg.Mode() == "OK")
        handshakeOk = 1;
    //}
	});

  mqtt::topic topic { cli, clientTopic, QOS };

  try {
		std::cout << "Connecting to the server at '" << SERVER_ADDRESS << "'..." << std::flush;
		auto tok = cli.connect(connOpts);
		tok->wait();
		// Subscribe to the topic using "no local" so that
		// we don't get own messages sent back to us
		std::cout << "Ok\nJoining the group..." << std::flush;
		auto subOpts = mqtt::subscribe_options(NO_LOCAL);
		topic.subscribe(subOpts)->wait();
		std::cout << "Ok" << std::endl;
	}
	catch (const mqtt::exception& exc) {
		std::cerr << "\nERROR: Unable to connect. "
			<< exc.what() << std::endl;
		//return 1;
	}

  while(handshakeOk != 2) {
    if(handshakeOk == -1) {
      rapidjson::StringBuffer msgBuffer;
      rapidjson::Writer<rapidjson::StringBuffer> usrMsg(msgBuffer);
      MessageModels::HandshakeMessage handshakeMsg;
      handshakeMsg.IpAdress(getLocalIP());
      handshakeMsg.Mode("REQ");
      handshakeMsg.Serialize(&usrMsg); 
      std::cout << "sending message: " << msgBuffer.GetString() << "\n";
      topic.publish(msgBuffer.GetString());   //publish 1st handshake message
      //handshakeOk = 0;
    }
    //wait to finish handshake
    if(handshakeOk == 1) {
      rapidjson::StringBuffer msgBuffer;
      rapidjson::Writer<rapidjson::StringBuffer> usrMsg(msgBuffer);
      MessageModels::HandshakeMessage handshakeMsg;
      handshakeMsg.IpAdress(getLocalIP());
      handshakeMsg.Mode("REQOK");
      handshakeMsg.Serialize(&usrMsg); 
      std::cout << "sending message: " << msgBuffer.GetString() << "\n";
      topic.publish(msgBuffer.GetString());   //publish 3rd handshake message
      handshakeOk = 2;
    }
    gpioDelay(1000000);    //timeout before resending
  }

  cli.disconnect();   //disconnect

  LOG_F(INFO, "Handshake ok, continue!");
  return 0;
}

int sendSetupMessageTeacher() {
  //create message for student client and push to queue
  std::lock_guard<std::mutex> lck {mutMQ};
  msgQueueQuality.push(qualMsg);
  condMQ.notify_all();
  return 0;
}

int sendSetupMessageStudent() {
  //create message for teacher client and push to queue
  std::lock_guard<std::mutex> lck {mutMQ};
  msgQueueSettings.push(settMsg);
  condMQ.notify_all();
  return 0; 
}

int handshakeConnection() {
  int res = -1;
  
  if(mode == "Teacher")
    res = handshakeConnectionTeacher();
  else
    res = handshakeConnectionStudent();

  return res;
}

int sendSetupMessage() {
  int res = -1;

  if(mode == "Teacher")
    res = sendSetupMessageTeacher();
  else
    res = sendSetupMessageStudent();

  return res;
}

//in teacher mode, send heartbeats every 1s
void startHeartbeats() {
  int timeoutCnt = 0;

  while(1) {
    if(mode == "Teacher") {
      //push outgoing heartbeat to message queue
      msgQueueHeartbeats.push("HEARTBEAT");

      //wait for answer   
      std::unique_lock<std::mutex> lck(mutHB);   
      //condHB.wait(lck, []{ return heartbeatReady; });
      bool timedOut = condHB.wait_for(lck, 5s, []{ return true; });
      lck.unlock();

      LOG_F(INFO, "Timeout: %d", timedOut);

      //answer timeout, increase timeout counter
      if(!timedOut) {
        LOG_F(INFO, "Heartbeat timed out!");
        timeoutCnt++;
      }
      else {
        LOG_F(INFO, "Heartbeat ACK received!");
        timeoutCnt = 0;
        disconnected = true;
      }

      LOG_F(INFO, "Sleeping...");
      std::this_thread::sleep_for(2s);      
    }
    if(mode == "Student") {
      std::unique_lock<std::mutex> lck(mutHB);
      //condHB.wait(lck, []{ return heartbeatReady; });
      bool timedOut = condHB.wait_for(lck, 5s, []{ return true; });
      heartbeatReady = false;
      lck.unlock();

      //answer timeout, increase timeout counter
      if(!timedOut) {
        LOG_F(INFO, "Heartbeat timed out!");
        timeoutCnt++;
      }
      else {
        LOG_F(INFO, "Heartbeat received! Sending Ack!");
        msgQueueHeartbeats.push("HEARTBEAT_ACK"); //send ack
        timeoutCnt = 0;
        disconnected = false;
      }
    }

    //if timeout counter too high, alert user
    if(timeoutCnt >= 3) {
      LOG_F(ERROR, "Cpt disconnected!");
      disconnected = true;
      DisplayHandler::updateDisplay();
    }
  }
}