#!/bin/bash
sudo /home/ubuntu/RPiClient/SFTClient