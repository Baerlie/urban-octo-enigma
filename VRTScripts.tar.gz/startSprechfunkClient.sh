#!/bin/bash
sudo /apps/vrt/VRTrainer