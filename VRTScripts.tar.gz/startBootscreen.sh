#!/bin/bash
sudo python3 /apps/vrt/scripts/hd44780/lcd_startup.py