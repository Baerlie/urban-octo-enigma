#!/bin/bash
sudo python3 /home/ubuntu/hd44780/lcd_startup.py